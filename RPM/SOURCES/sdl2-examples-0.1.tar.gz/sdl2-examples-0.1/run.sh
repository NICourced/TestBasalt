#!/bin/sh
make run
make fullclean
