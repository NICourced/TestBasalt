# Zig SDL2 example

Tested with these versions of Zig on Arch Linux:

* 0.7.1
* 0.8.0
* 0.9.1
