# Common Lisp

This example uses SDL2 and QuickLisp, and is based on examples from [cl-sdl2](https://github.com/lispgames/cl-sdl2).

The main function and package name are defined at the top of the `Makefile`.

Tested on Arch Linux (works) and macOS (didn't work).

* [Additional examples for Common Lisp](https://github.com/lispgames/cl-sdl2/tree/master/examples)
