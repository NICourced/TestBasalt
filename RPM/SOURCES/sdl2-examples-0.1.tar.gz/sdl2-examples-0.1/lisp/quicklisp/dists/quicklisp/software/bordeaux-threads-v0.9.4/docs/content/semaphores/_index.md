---
date: 2022-01-07T08:00:00Z
title: Semaphores dictionary
weight: 5
---

##### [Class SEMAPHORE](semaphore)

##### [Function SEMAPHOREP](semaphorep)

##### [Function MAKE-SEMAPHORE](make-semaphore)

##### [Function SIGNAL-SEMAPHORE](signal-semaphore)

##### [Function WAIT-ON-SEMAPHORE](wait-on-semaphore)
