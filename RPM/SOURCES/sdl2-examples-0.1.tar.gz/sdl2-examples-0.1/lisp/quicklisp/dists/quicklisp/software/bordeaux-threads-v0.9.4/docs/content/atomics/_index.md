---
date: 2022-01-07T08:00:00Z
title: Atomics dictionary
weight: 6
---

##### [Class ATOMIC-INTEGER](atomic-integer)

##### [Function ATOMIC-INTEGER-P](atomic-integer-p)

##### [Function MAKE-ATOMIC-INTEGER](make-atomic-integer)

##### [Function ATOMIC-INTEGER-CAS](atomic-integer-cas)

##### [Function ATOMIC-INTEGER-DECF](atomic-integer-decf)

##### [Function ATOMIC-INTEGER-INCF](atomic-integer-incf)

##### [Function ATOMIC-INTEGER-VALUE](atomic-integer-value)

