## About Float-Features
This is a wrapper library for IEEE floating point features not present in the Common Lisp standard.

## Implementation Support
The following implementations are currently partially or entirely supported:

* abcl
* allegro
* ccl
* clasp
* cmucl
* ecl
* mezzano
* mkcl
* sbcl
* lispworks
