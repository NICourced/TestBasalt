** NOTE ** 

This is unmaintained code. Gary King is no longer an active Lisper. Good luck out there.

trivial-timeout
===============

portable and possibly dangerous timeout library for Common Lisp.

