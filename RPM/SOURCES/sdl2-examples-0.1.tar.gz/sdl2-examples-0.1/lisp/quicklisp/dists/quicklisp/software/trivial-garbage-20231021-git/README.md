[![Build Status](https://travis-ci.org/trivial-garbage/trivial-garbage.svg?branch=master)](https://travis-ci.org/trivial-garbage/trivial-garbage)

trivial-garbage provides a portable API to finalizers, weak
hash-tables and weak pointers on all major implementations of the
Common Lisp programming language.

Documentation is available at the [project's website][1].

It is placed in the public domain with absolutely no warranty.


[1]: http://common-lisp.net/project/trivial-garbage/
