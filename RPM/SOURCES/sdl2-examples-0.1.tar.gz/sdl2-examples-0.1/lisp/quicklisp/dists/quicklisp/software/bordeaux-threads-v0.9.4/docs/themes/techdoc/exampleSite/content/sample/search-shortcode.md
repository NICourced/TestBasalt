---
title: "Search Shortcode"
date: 2020-03-30T18:49:06Z
showPagination: false
---

{{% panel status="primary" title="Note" icon="far fa-lightbulb" %}}
Search Shortcode powered by [Algolia](https://www.algolia.com/)

You can create a search page just by adding `search` shortcode.
{{% /panel %}}

{{< search >}}{{< /search >}}
