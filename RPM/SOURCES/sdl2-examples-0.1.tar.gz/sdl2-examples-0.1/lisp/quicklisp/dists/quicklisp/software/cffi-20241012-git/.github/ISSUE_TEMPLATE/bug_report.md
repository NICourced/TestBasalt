---
name: Bug report
about: Report a bug
title: ''
labels: ''
assignees: ''

---

You are about to report a bug in the Common Lisp Foreign Function Interface project (CFFI).
If you are looking for the Python CFFI project, you can go to its [bug tracker](https://foss.heptapod.net/pypy/cffi/-/issues) or read the [documentation](https://cffi.readthedocs.io/en/latest/).
