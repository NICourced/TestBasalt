---
date: 2022-01-07T08:00:00Z
title: Locks dictionary
weight: 3
---

##### [Class LOCK](lock)

##### [Function LOCKP](lockp)

##### [Class RECURSIVE-LOCK](recursive-lock)

##### [Function RECURSIVE-LOCK-P](recursive-lock-p)

##### [Function LOCK-NAME, LOCK-NATIVE-LOCK](lock-readers)

##### [Host type NATIVE-LOCK](native-lock)

##### [Function NATIVE-LOCK-P](native-lock-p)

##### [Host type NATIVE-RECURSIVE-LOCK](native-recursive-lock)

##### [Function NATIVE-RECURSIVE-LOCK-P](native-recursive-lock-p)

##### [Function MAKE-LOCK](make-lock)

##### [Function ACQUIRE-LOCK, RELEASE-LOCK](acquire-release-lock)

##### [Macro WITH-LOCK-HELD](with-lock-held)

##### [Function MAKE-RECURSIVE-LOCK](make-recursive-lock)

##### [Function ACQUIRE-RECURSIVE-LOCK, RELEASE-RECURSIVE-LOCK](acquire-release-recursive-lock)

##### [Macro WITH-RECURSIVE-LOCK-HELD](with-recursive-lock-held)
