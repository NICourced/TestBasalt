# Python

* First install SDL2.
* Then install PySDL2 (the package may be named `python-pysdl2`).
* Alternatively, install PySDL2 with `easy_install`.

More information about getting started with PySDL2:

http://pysdl2.readthedocs.org/en/latest/
