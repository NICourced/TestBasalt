Requirements
------------

* nasm
* Xcode Command Line Tools
* sdl2
