Requirements
------------

* nasm
* sdl2
