Requirements
------------

* nasm
* GoLink
* sdl2
