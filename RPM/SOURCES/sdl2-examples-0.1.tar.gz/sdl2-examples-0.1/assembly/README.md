Note that the executables that are generated from Assembly are only intended to work on the target system they are crafted for.
