## Requirements

* C11 compiler
* pkg-config
* SDL2

## macOS

Install pkg-config using brew, or use `-LSDL2` in the Makefile instead of using pkg-config.
