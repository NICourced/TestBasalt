Requirements
------------

* git
* fpc
* sdl2
