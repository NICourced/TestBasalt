Instructions
------------

# Installation of SDL2 for Lua

### With luarocks

`sudo luarocks install lua-sdl2`

### For Arch Linux

`pacman -S lua-sdl2`

# Running

If `lua main.lua` does not work, try using a specific Lua version that may have the SDL2 bindings available on your system, like `lua5.3 main.lua`.
